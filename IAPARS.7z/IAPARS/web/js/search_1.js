/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function optionCheck() {
    var option = document.getElementById("select_d").value;
    if (option == "zone") {
        document.getElementById("zone").style.visibility = "visible";
        document.getElementById("user_Type").style.visibility = "hidden";
    }
    if (option == "user_Type") {
        document.getElementById("user_Type").style.visibility = "visible";
        document.getElementById("zone").style.visibility = "hidden";
    }
}

function userCheck() {

    document.getElementById("user_type").style.visibility = "visible";
}


function idCheck() {

    document.getElementById("user_id").style.visibility = "visible";
    document.getElementById("user_id").setAttribute("value","all");
}

 
   