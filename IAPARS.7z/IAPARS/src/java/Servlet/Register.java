package Servlet;

import Controllers.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author abena
 */
public class Register extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection conn = null;
        String userID=request.getParameter("userId");
        String pw_hash = BCrypt.hashpw(request.getParameter("userPassword"), BCrypt.gensalt());
        String userType = request.getParameter("userType");
        String userLastName = request.getParameter("userLastName");
        String userFirstName = request.getParameter("userFirstName");
        String userGender = request.getParameter("userGender");
        String userEmail = request.getParameter("userEmail");
        String userAddress1 = request.getParameter("userAddress1");
        String userCity = request.getParameter("userCity");
        String userZone = request.getParameter("userZone");
        String userPostCode = request.getParameter("userPostCode");
        String userOccupation = request.getParameter("userOccupation");
        String userContactNumber = request.getParameter("userContactNumber");
       
        

        try {

            Connection con = ConnectDB.getDBConnection();
            Users_Info b = new Users_Info();
            b.setUserFirstName(userFirstName);
            b.setUserEmail(userEmail);
            b.setUserPassword(pw_hash);
            b.setUserGender(userGender);
            b.setUserAddress1(userAddress1);
            b.setUserZone(userZone);
            b.setUserID(userID);
            b.setUserContactNumber(userContactNumber);
            b.setUserOccupation(userOccupation);
            b.setUserPostCode(userPostCode);
            b.setUserLastName(userLastName);
            b.setUserType(userType);
            b.setUserCity(userCity);
            b.insert(con);
            b.insert_info(con);
            request.setAttribute("save", b);
            RequestDispatcher ds = request.getRequestDispatcher("/user_add.jsp");
            ds.forward(request, response);

        } catch (Exception ex) {
            ex.getStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
