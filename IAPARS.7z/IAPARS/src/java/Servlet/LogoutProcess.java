package Servlet;


import Controllers.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogoutProcess extends ConnectionPoolServlet {
	private boolean debug = true;

	
  	public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
  			throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);		
		
		PrintWriter out = response.getWriter();

		Users_Info user = (Users_Info)session.getAttribute("user");
		Users_Info staff = (Users_Info)session.getAttribute("staff");
		Login login = (Login)session.getAttribute("login");
	
		if ( login.getUserID() != "" ){		
			// Login login = new Login(false, "", "");			
			login.resetVariable();
			user.resetVariable();	
			staff.resetVariable();
			session.setAttribute("login", login);	
			session.setAttribute("user", user);
			session.setAttribute("staff", staff);
			
			
			gotoPage("/login.jsp", request, response);
		}else{
			gotoPage("/login.jsp", request, response);
		}		
	}
}

