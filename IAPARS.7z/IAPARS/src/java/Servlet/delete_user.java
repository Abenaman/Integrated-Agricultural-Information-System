/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import Controllers.ConnectDB;
import Controllers.Users_Info;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author abena
 */
public class delete_user extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

        } finally {
            out.close();
        }
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    HttpSession session = request.getSession(true);
      String ID =  request.getParameter("id");     
         
try{  
    
    Connection  con = ConnectDB.getDBConnection();
        Users_Info user = new Users_Info();
        user.Delete(con,ID);
        request.setAttribute("display", user);
        RequestDispatcher ds = request.getRequestDispatcher("/JSP/AdminCenter.jsp");
        ds.forward(request, response);
}
catch(Exception e){   
 PrintWriter p=response.getWriter();
    p.println("not found");
}
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
