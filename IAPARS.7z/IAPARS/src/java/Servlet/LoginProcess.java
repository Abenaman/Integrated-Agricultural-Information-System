package Servlet;

import Controllers.DatabaseUtilities;
import Controllers.BCrypt;
import Controllers.Login;
import Controllers.Users_Info;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginProcess extends ConnectionPoolServlet {

    private boolean debug = false;
    private String login_email;
    private String loginPassword;
    private String userID = "";
    private String userPassword = "";
    private String userFirstName = "";
    private String userLastName = "";
    private String userType = "";
    private ResultSet myResultSet = null;
    private String query = "";
    private String userGender = "";
    private String userEmail = "";
    private String userICNumber = "";
    private String userAddress1 = "";
    private String userAddress2 = "";
    private String userCity = "";
    private String userState = "";
    private String userPostCode = "";
    private String userCountry = "";
    private String userOccupation = "";
    private String userContactNumber = "";
    private int userTotReservation = 0;

    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        login_email = request.getParameter("email");
        loginPassword = request.getParameter("password");
        String errorMsg;

        //String table;
        try {

            query = "select * from users  where email = '" + login_email + "'";
            Connection connection = connectionPool.getConnection();

            myResultSet = DatabaseUtilities.getQueryResultSet(connection, query, false);

            connectionPool.free(connection);
            //table = results.toHTMLTable("#FFAD00");
        } catch (Exception e) {
            errorMsg = "Error: " + e;
        }

        resetVariable();

        if (myResultSet != null) {
            try {
                while (myResultSet.next()) {
                    String dbhash = myResultSet.getString(4);
                    if (BCrypt.checkpw(loginPassword, dbhash)) {

                        userID = myResultSet.getString("id");
                        userPassword = myResultSet.getString("password");
                        userFirstName = myResultSet.getString("name");
                        userType = myResultSet.getString("userType");
                        userEmail = myResultSet.getString("email");

                    }
                }
            } catch (SQLException sqle) {
                System.out.println("Error connecting: " + sqle);
            }
        }

        if (userID != "") {

            HttpSession session = request.getSession(true);

            Login login = new Login(true, userID, userType, userFirstName);
            session.setAttribute("login", login);

            if ((userType.equals("admin")) || (userType.equals("expert")) || (userType.equals("knowledgeEngineer"))) {
                Users_Info staff = new Users_Info(userTotReservation, userID, userPassword, userType, userFirstName, userLastName, userGender, userEmail, userICNumber, userAddress1, userAddress2, userCity, userState, userPostCode, userCountry, userOccupation, userContactNumber, userTotReservation);
                session.setAttribute("staff", staff);
                gotoPage("/main.jsp", request, response);
            } else {
                Users_Info user = new Users_Info(userTotReservation, userID, userPassword, userType, userFirstName, userLastName, userGender, userEmail, userICNumber, userAddress1, userAddress2, userCity, userState, userPostCode, userCountry, userOccupation, userContactNumber, userTotReservation);

                session.setAttribute("user", user);
            }
        } else {
            gotoPage("/login_invalid.jsp", request, response);
        }
    }

    private void resetVariable() {
        this.userID = "";
        this.userFirstName = "";
        this.userLastName = "";
        this.userType = "";
    }
}
