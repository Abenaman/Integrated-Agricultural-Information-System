/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Map {

    private String maps_name;
    private String maps_id;
    private String maps_description;

    public String getMaps_name() {
        return maps_name;
    }

    public void setMaps_name(String maps_name) {
        this.maps_name = maps_name;
    }

    public String getMaps_id() {
        return maps_id;
    }

    public void setMaps_id(String maps_id) {
        this.maps_id = maps_id;
    }

    public String getMaps_description() {
        return maps_description;
    }

    public void setMaps_description(String maps_description) {
        this.maps_description = maps_description;
    }

}
