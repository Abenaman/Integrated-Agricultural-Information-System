package Controllers;

import java.sql.*;

public class ConnectDB {

    public static Connection conn;
    private Statement statement;
    ResultSet rs = null;
    public static ConnectDB db;

    public static String url = "jdbc:mysql://localhost:3306/";
    public static String dbName = "iapars";
    public static String driver = "com.mysql.jdbc.Driver";
    public static String userName = "root";  // blanked for publication
    public static String password = "";

    public static Connection getDBConnection() {
        System.out.println("Start of getDBConnection.");

        try {
            Class.forName(driver).newInstance();
            System.out.println("driver.newInstance gotten.");
            conn = DriverManager.getConnection(url + dbName, userName, password);
            System.out.println("Connection gotten: " + conn + ".");

            return conn;
        } catch (Exception sqle) {
            sqle.printStackTrace();
            return null;
        }

    }

    public ResultSet getData(String str) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url + dbName, userName, password);
            statement = conn.createStatement();
            rs = statement.executeQuery(str);
        } catch (Exception e) {
        }
        return rs;
    }
public int setData(String str){
        int i=0;
        try{
           
           Class.forName(driver).newInstance();
            System.out.println("driver.newInstance gotten.");
            conn = DriverManager.getConnection(url + dbName, userName, password);
            //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root", "root");
            statement=conn.createStatement();
            statement.execute(str);
            i = statement.getUpdateCount();
        }catch(Exception e){
           
        }
        return i;
    }


}
