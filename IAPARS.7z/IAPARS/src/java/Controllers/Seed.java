/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Seed extends Product{
        private String seed_id;
    private String seed_type;
    private String seeding_date;

    public String getSeed_id() {
        return seed_id;
    }

    public void setSeed_id(String seed_id) {
        this.seed_id = seed_id;
    }

    public String getSeed_type() {
        return seed_type;
    }

    public void setSeed_type(String seed_type) {
        this.seed_type = seed_type;
    }

    public String getSeeding_date() {
        return seeding_date;
    }

    public void setSeeding_date(String seeding_date) {
        this.seeding_date = seeding_date;
    }
   

}
