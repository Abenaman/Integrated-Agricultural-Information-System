/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Store {
        private String store_id;
    private String store_site;
    private String store_in;
    private String store_out;

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getStore_site() {
        return store_site;
    }

    public void setStore_site(String store_site) {
        this.store_site = store_site;
    }

    public String getStore_in() {
        return store_in;
    }

    public void setStore_in(String store_in) {
        this.store_in = store_in;
    }

    public String getStore_out() {
        return store_out;
    }

    public void setStore_out(String store_out) {
        this.store_out = store_out;
    }

}
