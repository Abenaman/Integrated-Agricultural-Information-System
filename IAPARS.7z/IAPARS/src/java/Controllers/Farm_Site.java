/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Farm_Site {
        private String site_id;
    private String site_info;
    private String site_location;
    private String site_name;
    private String site_size;

    public String getSite_id() {
        return site_id;
    }

    public void setSite_id(String site_id) {
        this.site_id = site_id;
    }

    public String getSite_info() {
        return site_info;
    }

    public void setSite_info(String site_info) {
        this.site_info = site_info;
    }

    public String getSite_location() {
        return site_location;
    }

    public void setSite_location(String site_location) {
        this.site_location = site_location;
    }

    public String getSite_name() {
        return site_name;
    }

    public void setSite_name(String site_name) {
        this.site_name = site_name;
    }

    public String getSite_size() {
        return site_size;
    }

    public void setSite_size(String site_size) {
        this.site_size = site_size;
    }


}
