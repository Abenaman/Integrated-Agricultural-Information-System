package Controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.*;

public final class Users_Info extends Users {

    private String userFirstName = "";
    private String userLastName = "";
    private String userGender = "";
    private String userICNumber = "";
    private String userAddress1 = "";
    private String userAddress2 = "";
    private String userCity = "";
    private String userState = "";
    private String userPostCode = "";
    private String userZone = "";
    private String userOccupation = "";
    private String userContactNumber = "";
    private int userTotReservation = 0;
    private String alert;
    private String date;
    private String message;
    PreparedStatement pst;
    Connection conn = null;
    ResultSet rs = null;

    public Users_Info() {
    }

    public Users_Info(int userRecNumber, String userID, String userPassword, String userType,
            String userFirstName, String userLastName, String userGender, String userEmail,
            String userICNumber, String userAddress1, String userAddress2, String userCity,
            String userState, String userPostCode, String userZone, String userOccupation,
            String userContactNumber, int userTotReservation) {

        setUserID(userID);
        setUserPassword(userPassword);
        setUserType(userType);
        setUserFirstName(userFirstName);
        setUserLastName(userLastName);
        setUserGender(userGender);
        setUserEmail(userEmail);
        setUserICNumber(userICNumber);
        setUserAddress1(userAddress1);
        setUserAddress2(userAddress2);
        setUserCity(userCity);
        setUserState(userState);
        setUserPostCode(userPostCode);
        setUserZone(userZone);
        setUserOccupation(userOccupation);
        setUserContactNumber(userContactNumber);
        setUserTotReservation(userTotReservation);
    }

    public void setPropertyFromRequestParameter(HttpServletRequest request) {
        //setUserRecNumber(userRecNumber);		
        setUserID(request.getParameter("userID"));
        setUserPassword(request.getParameter("userPassword"));
        setUserType(request.getParameter("userType"));
        setUserFirstName(request.getParameter("userFirstName"));
        setUserLastName(request.getParameter("userLastName"));
        setUserGender(request.getParameter("userGender"));
        setUserEmail(request.getParameter("userEmail"));
        setUserICNumber(request.getParameter("userICNumber"));
        setUserAddress1(request.getParameter("userAddress1"));
        setUserAddress2(request.getParameter("userAddress2"));
        setUserCity(request.getParameter("userCity"));
        setUserState(request.getParameter("userState"));
        setUserPostCode(request.getParameter("userPostCode"));
        setUserZone(request.getParameter("userZone"));
        setUserOccupation(request.getParameter("userOccupation"));
        setUserContactNumber(request.getParameter("userContactNumber"));
        setUserTotReservation(Integer.parseInt(request.getParameter("userTotReservation")));
    }

    public void setPropertyFromOtherUserBean(Users_Info user) {
        setUserID(user.getUserID());
        setUserPassword(user.getUserPassword());
        setUserType(user.getUserType());
        setUserFirstName(user.getUserFirstName());
        setUserLastName(user.getUserLastName());
        setUserGender(user.getUserGender());
        setUserEmail(user.getUserEmail());
        setUserICNumber(user.getUserICNumber());
        setUserAddress1(user.getUserAddress1());
        setUserAddress2(user.getUserAddress2());
        setUserCity(user.getUserCity());
        setUserState(user.getUserState());
        setUserPostCode(user.getUserPostCode());
        setUserZone(user.getUserZone());
        setUserOccupation(user.getUserOccupation());
        setUserContactNumber(user.getUserContactNumber());
        setUserTotReservation(user.getUserTotReservation());
    }

    public void resetVariable() {
        setUserID("");
        setUserPassword("");
        setUserType("");
        setUserFirstName("");
        setUserLastName("");
        setUserGender("");
        setUserEmail("");
        setUserICNumber("");
        setUserAddress1("");
        setUserAddress2("");
        setUserCity("");
        setUserState("");
        setUserPostCode("");
        setUserZone("");
        setUserOccupation("");
        setUserContactNumber("");
    }

    @Override
    public void setUserID(String userID) {
        //userFirstName = ServletUtilities.replaceIfMissing(userFirstName, "Unknow First Name");
        this.userID = userID;
    }

    @Override
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    @Override
    public void setUserType(String userType) {
        this.userType = userType;
    }

    @Override
    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    @Override
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public void setUserICNumber(String userICNumber) {
        this.userICNumber = userICNumber;
    }

    public void setUserAddress1(String userAddress1) {
        this.userAddress1 = userAddress1;
    }

    public void setUserAddress2(String userAddress2) {
        this.userAddress2 = userAddress2;
    }

    public void setUserCity(String userCity) {
        this.userCity = userCity;
    }

    public void setUserState(String userState) {
        this.userState = userState;
    }

    public void setUserPostCode(String userPostCode) {
        this.userPostCode = userPostCode;
    }

    public void setUserZone(String userCountry) {
        this.userZone = userCountry;
    }

    public void setUserOccupation(String userOccupation) {
        this.userOccupation = userOccupation;
    }

    public void setUserContactNumber(String userContactNumber) {
        this.userContactNumber = userContactNumber;
    }

    public void setUserTotReservation(int userTotReservation) {
        this.userTotReservation = userTotReservation;
    }

    @Override
    public String getUserID() {
        return userID;
    }

    @Override
    public String getUserPassword() {
        return userPassword;
    }

    @Override
    public String getUserType() {
        return userType;
    }

    @Override
    public String getUserFirstName() {
        return userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public String getUserGender() {
        return userGender;
    }

    @Override
    public String getUserEmail() {
        return userEmail;
    }

    public String getUserICNumber() {
        return userICNumber;
    }

    public String getUserAddress1() {
        return userAddress1;
    }

    public String getUserAddress2() {
        return userAddress2;
    }

    public String getUserCity() {
        return userCity;
    }

    public String getUserState() {
        return userState;
    }

    public String getUserPostCode() {
        return userPostCode;
    }

    public String getUserZone() {
        return userZone;
    }

    public String getUserOccupation() {
        return userOccupation;
    }

    public String getUserContactNumber() {
        return userContactNumber;
    }

    public int getUserTotReservation() {

        return userTotReservation;
    }

    public boolean insert(Connection conn) {

        try {

//Add the data into the database
            String sql = "insert into users(email,id, name, password,userType) values (?,?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, this.getUserEmail());
            pst.setString(2, this.getUserID());
            pst.setString(3, this.getUserFirstName());
            pst.setString(4, this.getUserPassword());
            pst.setString(5, this.getUserType());
            pst.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean insert_info(Connection conn) {

        try {

//Add the data into the database
            String sql = "insert into users_info(city, id, last_name, userAddress1, userContactNumber, userZone, userGender, userType,userPostCode) values (?,?,?,?,?,?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, this.getUserCity());
            pst.setString(2, this.getUserID());
            pst.setString(3, this.getUserLastName());
            pst.setString(4, this.getUserAddress1());
            pst.setString(5, this.getUserContactNumber());
            pst.setString(6, this.getUserZone());
            pst.setString(7, this.getUserGender());
            pst.setString(8, this.getUserType());
            pst.setString(9, this.getUserPostCode());

            pst.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean Delete(Connection conn, String id) {

        try {
            String sql = "insert into users_trash select * from users where id =?";
            pst.setString(1, id);
            pst = conn.prepareStatement(sql);
            pst.execute();
            while (pst.getResultSet().next()) {
                String sql1 = "delete from users u,users_info ui where u.id=?";
                pst.setString(1, id);
                pst = conn.prepareStatement(sql1);
                pst.execute();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean Search(Connection conn) {

        try {
            String sql = "select * from users u,users_info ui where u.id=? and u.userType=? and ui.userCountry=?";
            pst.setString(1, this.getUserID());
            pst.setString(2, this.getUserType());
            pst.setString(3, this.getUserZone());
            pst = conn.prepareStatement(sql);
            pst.execute();       
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

}
