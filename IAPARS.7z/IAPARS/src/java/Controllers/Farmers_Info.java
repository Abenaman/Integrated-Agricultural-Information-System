/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Farmers_Info {
        private String farmers_name;
    private String farmers_id;
    private String farmers_sex;
    private String farmers_phone;
    private String farmers_address;
    private String farmers_experiance;
    private String farmers_training;
    private String farmers_area;
    private String farmers_main_crop;
    private String farmers_image;
    private String date_joined;

    public String getFarmers_name() {
        return farmers_name;
    }

    public void setFarmers_name(String farmers_name) {
        this.farmers_name = farmers_name;
    }

    public String getFarmers_id() {
        return farmers_id;
    }

    public void setFarmers_id(String farmers_id) {
        this.farmers_id = farmers_id;
    }

    public String getFarmers_sex() {
        return farmers_sex;
    }

    public void setFarmers_sex(String farmers_sex) {
        this.farmers_sex = farmers_sex;
    }

    public String getFarmers_phone() {
        return farmers_phone;
    }

    public void setFarmers_phone(String farmers_phone) {
        this.farmers_phone = farmers_phone;
    }

    public String getFarmers_address() {
        return farmers_address;
    }

    public void setFarmers_address(String farmers_address) {
        this.farmers_address = farmers_address;
    }

    public String getFarmers_experiance() {
        return farmers_experiance;
    }

    public void setFarmers_experiance(String farmers_experiance) {
        this.farmers_experiance = farmers_experiance;
    }

    public String getFarmers_training() {
        return farmers_training;
    }

    public void setFarmers_training(String farmers_training) {
        this.farmers_training = farmers_training;
    }

    public String getFarmers_area() {
        return farmers_area;
    }

    public void setFarmers_area(String farmers_area) {
        this.farmers_area = farmers_area;
    }

    public String getFarmers_main_crop() {
        return farmers_main_crop;
    }

    public void setFarmers_main_crop(String farmers_main_crop) {
        this.farmers_main_crop = farmers_main_crop;
    }

    public String getFarmers_image() {
        return farmers_image;
    }

    public void setFarmers_image(String farmers_image) {
        this.farmers_image = farmers_image;
    }

    public String getDate_joined() {
        return date_joined;
    }

    public void setDate_joined(String date_joined) {
        this.date_joined = date_joined;
    }


}
