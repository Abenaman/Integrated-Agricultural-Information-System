/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Soil {
        private String soil_id;
    private String soil_type;
    private String soil_metadata;
    private String s_location;

    public String getSoil_id() {
        return soil_id;
    }

    public void setSoil_id(String soil_id) {
        this.soil_id = soil_id;
    }

    public String getSoil_type() {
        return soil_type;
    }

    public void setSoil_type(String soil_type) {
        this.soil_type = soil_type;
    }

    public String getSoil_metadata() {
        return soil_metadata;
    }

    public void setSoil_metadata(String soil_metadata) {
        this.soil_metadata = soil_metadata;
    }

    public String getS_location() {
        return s_location;
    }

    public void setS_location(String s_location) {
        this.s_location = s_location;
    }
   

}
