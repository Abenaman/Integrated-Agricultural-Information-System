/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Harvest extends Farmers_Info {

    private String id;
    private String entry_date;
    private String harves_name;
    private String harvest_description;
    private String harvest_image;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEntry_date() {
        return entry_date;
    }

    public void setEntry_date(String entry_date) {
        this.entry_date = entry_date;
    }

    public String getHarves_name() {
        return harves_name;
    }

    public void setHarves_name(String harves_name) {
        this.harves_name = harves_name;
    }

    public String getHarvest_description() {
        return harvest_description;
    }

    public void setHarvest_description(String harvest_description) {
        this.harvest_description = harvest_description;
    }

    public String getHarvest_image() {
        return harvest_image;
    }

    public void setHarvest_image(String harvest_image) {
        this.harvest_image = harvest_image;
    }
    

}
