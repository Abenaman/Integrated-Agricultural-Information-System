/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

/**
 *
 * @author HCTE
 */
public class Fertlizer {
        private String f_id;
    private String f_amount;
    private String f_name;
    private String f_rate;

    public String getF_id() {
        return f_id;
    }

    public void setF_id(String f_id) {
        this.f_id = f_id;
    }

    public String getF_amount() {
        return f_amount;
    }

    public void setF_amount(String f_amount) {
        this.f_amount = f_amount;
    }

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getF_rate() {
        return f_rate;
    }

    public void setF_rate(String f_rate) {
        this.f_rate = f_rate;
    }


}
