package Controllers;


public final class Login {

    private boolean userLogin = false;
    private String userID = "";
    private String userType = "";
    private String userName = "";

    public Login(boolean userLogin, String userID, String userType,String userName) {
        setUserLogin(userLogin);
        setUserID(userID);
        setUserType(userType);
        setUserName(userName);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Login() {
    }

    public void resetVariable() {
        setUserLogin(false);
        setUserID("");
        setUserType("");
    }

    public void setUserLogin(boolean userLogin) {
        this.userLogin = userLogin;
    }

    public boolean isUserLogin() {
        return userLogin;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserType() {
        return userType;
    }

}
